CMCXmlParser._FilePathToXmlStringMap.Add(
	'BrowseSequences',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultToc Version=\"1\" DescendantCount=\"113\">' +
	'    <TocEntry Title=\"About Wizard Items\" DescendantCount=\"4\">' +
	'        <TocEntry Title=\"Wizard Items\" Link=\"/Content/Wizard_Builder/Items/Wizard_Items.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Add a Desktop Item\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Add a Plug-In Item\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Add/Edit a Value Item\" Link=\"/Content/Wizard_Builder/Items/Add_Edit_a_Value_Item.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Connect Wizard Items\" Link=\"/Content/Wizard_Builder/Items/Connect_Wizard_Items.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Execution Mode of Wizard Items\" Link=\"/Content/Wizard_Builder/Items/Execution_Mode_of_Wizard_Items.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Annotation\" DescendantCount=\"5\">' +
	'        <TocEntry Title=\"Annotation Layer\" Link=\"/Content/Annotation/Annotation_Layer.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Annotation Toolbar\" Link=\"/Content/Toolbars/Annotation_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Annotation Drop-Down Menu\" Link=\"/Content/Annotation/Annotation_Drop-Down_Menu.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Working with Annotation Objects\" Link=\"/Content/Annotation/Working_with_Annotation_Objects.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Working with Annotation Text Boxes\" Link=\"/Content/Annotation/Working_with_Annotation_Text_Boxes.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"AOI\" DescendantCount=\"6\">' +
	'        <TocEntry Title=\"AOI\" Link=\"/Content/AOI/AOI.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"AOI Toolbar\" Link=\"/Content/Toolbars/AOI_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"AOI Editor\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"AOI Pixel Selection Tool\" Link=\"/Content/AOI/AOI_Pixel_Selection_Tool.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Merge AOIs\" Link=\"/Content/AOI/Merge_AOIs.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"AOI Pixels\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Change AOI Marker Symbol\" Link=\"/Content/AOI/Change_AOI_Marker_Symbol.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"View AOI Spectra\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"AOI Layer Properties\" Link=\"/Content/Properties/AOI_Layer_Properties.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"COMET Studio\" DescendantCount=\"3\">' +
	'        <TocEntry Title=\"Using the Wizard Builder\" Link=\"/Content/Wizard_Builder/Using_the_Wizard_Builder.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Product Windows\" Link=\"/Content/Products/Product_Windows.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"About the Quick-Look Data Fusion Plug-In\" Link=\"/Content/QuickLookDataFusion/about_the_quick-look_data_fusion_plug-in.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Data Set Properties\" DescendantCount=\"1\">' +
	'        <TocEntry Title=\"Data Set Properties\" Link=\"/Content/Importers_Exporters/Options/Import_Data_Options.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Spectral Cube Properties\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Resolution Properties\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Wavelengths Properties\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Initial Display Properties\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Attributes Properties\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"GCP\" DescendantCount=\"4\">' +
	'        <TocEntry Title=\"GCP\" Link=\"/Content/Geo/GCP.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Geo Toolbar\" Link=\"/Content/Toolbars/Geo_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"GCP Editor\" Link=\"/Content/Geo/GCP_Editor.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"GCP Lists\" Link=\"/Content/Geo/GCP_Lists.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Geo\" DescendantCount=\"1\">' +
	'        <TocEntry Title=\"Georeference\" Link=\"/Content/Geo/Georeference.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"GeoCorrection\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"GeoCorrection CPM Generation\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Histogram Window\" DescendantCount=\"10\">' +
	'        <TocEntry Title=\"Histogram Window\" Link=\"/Content/Tools/Histogram_Window/Histogram_Window.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Stretch Type\" Link=\"/Content/Tools/Histogram_Window/Stretch_Type.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Working with the Histogram Window Display\" Link=\"/Content/Tools/Histogram_Window/Working_with_the_Histogram_Window_Display.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Histogram Window Mouse Mode\" Link=\"/Content/Tools/Histogram_Window/Histogram_Window_Mouse_Mode.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Band Bad Values\" Link=\"/Content/Tools/Histogram_Window/Band_Bad_Values.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Set Spatial Sampling\" Link=\"/Content/Tools/Histogram_Window/Set_Spatial_Sampling.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Spectral Band\" Link=\"/Content/Tools/Histogram_Window/Displayed_Band.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Color Map\" Link=\"/Content/Tools/Histogram_Window/Color_Map.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Print the Histogram Window\" Link=\"/Content/Tools/Histogram_Window/Print_the_Histogram_Window.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Save the Histogram Window Data\" Link=\"/Content/Tools/Histogram_Window/Save_the_Histogram_Window_Data.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Import and Export Files\" DescendantCount=\"7\">' +
	'        <TocEntry Title=\"Importers\" Link=\"/Content/Importers_Exporters/Importers.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Exporters\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"About COMET Suite Data Files\" Link=\"/Content/about_opticks_suite_data_files.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Export Data Set\" Link=\"/Content/Importers_Exporters/Export_Data_Set.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Export Results Matrix\" Link=\"/Content/Importers_Exporters/Export_Results.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Export Product Data\" Link=\"/Content/Importers_Exporters/Export_Product_Data.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Export Shape File\" Link=\"/Content/Importers_Exporters/Export_Shape_File.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Data Set Properties\" Link=\"/Content/Importers_Exporters/Options/Import_Data_Options.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Options\" DescendantCount=\"1\">' +
	'        <TocEntry Title=\"Options\" Link=\"/Content/Options/Options.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Options: File Tab\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Options: Edit Tab\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Options: View Tab\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Options: Progress Tab\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Options: Project Tab\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Options: Layers Tab\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Options: Status Bar Tab\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Products\" DescendantCount=\"7\">' +
	'        <TocEntry Title=\"Product Windows\" Link=\"/Content/Products/Product_Windows.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Create a New Product\" Link=\"/Content/Products/Create_a_New_Product.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Derive a Product\" Link=\"/Content/Products/Derive_a_Product.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Load a Template\" Link=\"/Content/Products/Load_a_Template.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Edit Selected View\" Link=\"/Content/Products/Edit_Selected_View.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Save a Template\" Link=\"/Content/Products/Save_a_Template.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Select Product Paper Size\" Link=\"/Content/Products/Select_Product_Paper_Size.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Projects\" DescendantCount=\"0\">' +
	'        <TocEntry Title=\"Projects\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Open a Project\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Create a Project\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Close a Project\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Save a Project\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"View Currently Open Projects\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Properties\" DescendantCount=\"12\">' +
	'        <TocEntry Title=\"Properties\" Link=\"/Content/Properties/Properties.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Data Elements Properties\" Link=\"/Content/Properties/Data_Elements_Properties.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Windows Properties\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Product Window Properties\" Link=\"/Content/Properties/Product_Window_Properties.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Histogram Window Properties\" Link=\"/Content/Properties/Histogram_Window_Properties.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Scripting Window Properties\" Link=\"/Content/Properties/Scripting_Window_Properties.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Spectrum Plot Properties\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Display Layer Properties\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"GCP Layer Properties\" Link=\"/Content/Properties/GCP_Layer_Properties.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Annotation Layer Properties\" Link=\"/Content/Properties/Annotation_Layer_Properties.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"AOI Layer Properties\" Link=\"/Content/Properties/AOI_Layer_Properties.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Latitude/Longitude Layer Properties\" Link=\"/Content/Properties/Latitude_Longitude_Layer_Properties.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Threshold Layer Properties\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Tie Point Layer Properties\" Link=\"/Content/Properties/Tie_Point_Layer_Properties.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Raster Layer Properties\" Link=\"/Content/Properties/Raster_Layer_Properties.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Raster Cube Layer Properties\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Plug-In Properties\" Link=\"/Content/Properties/Plug-In_Properties.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Security Markings\" DescendantCount=\"1\">' +
	'        <TocEntry Title=\"Security Markings\" Link=\"/Content/Importers_Exporters/Options/Classification_Tab.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Spectrum Window\" DescendantCount=\"0\">' +
	'        <TocEntry Title=\"Spectrum Window\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Working with the Spectrum Plot\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Spectrum Plot Mouse Mode\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Add a New Spectrum Plot\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Load a Predefined Signature\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Rename a Spectrum Plot\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Remove a Spectrum Plot\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Change the Colors in the Spectrum Plot\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Display Pixel Spectrum\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Print the Spectrum Window\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"The Quick-Look Data Fusion Plug-In\" DescendantCount=\"5\">' +
	'        <TocEntry Title=\"About the Quick-Look Data Fusion Plug-In\" Link=\"/Content/QuickLookDataFusion/about_the_quick-look_data_fusion_plug-in.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Starting the Quick-Look Data Fusion Plug-In\" Link=\"/Content/QuickLookDataFusion/starting_the_quick-look_data_fusion_plug-in.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Importing Data Sets\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Creating Tie Points\" Link=\"/Content/QuickLookDataFusion/creating_tie_points.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Selecting a ROI and Output Views\" Link=\"/Content/QuickLookDataFusion/Selecting_a_ROI_and_Output_Views.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Manipulating Fused Views\" Link=\"/Content/QuickLookDataFusion/manipulating_fused_views.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Tie Points\" DescendantCount=\"4\">' +
	'        <TocEntry Title=\"Tie Points\" Link=\"/Content/Tie_Points/Tie_Points.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Tie Point Toolbar\" Link=\"/Content/Toolbars/Tie_Point_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Tie Point Editor\" Link=\"/Content/Tie_Points/Tie_Point_Editor.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Delete Tie Points\" Link=\"/Content/Tie_Points/Delete_Tie_Points.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Toolbars\" DescendantCount=\"10\">' +
	'        <TocEntry Title=\"Toolbars\" Link=\"/Content/Toolbars/Toolbars.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Standard Toolbar\" Link=\"/Content/Toolbars/Standard_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Toolbox Toolbar\" Link=\"/Content/Toolbars/Toolbox_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Display Toolbar\" Link=\"/Content/Toolbars/Display_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Layer Toolbar\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"AOI Toolbar\" Link=\"/Content/Toolbars/AOI_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Geo Toolbar\" Link=\"/Content/Toolbars/Geo_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Tie Point Toolbar\" Link=\"/Content/Toolbars/Tie_Point_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Annotation Toolbar\" Link=\"/Content/Toolbars/Annotation_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Brightness Toolbar\" Link=\"/Content/Toolbars/Brightness_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Measurement Toolbar\" Link=\"/Content/Toolbars/Measurement_Toolbar.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Tutorials for COMET Studio\" DescendantCount=\"1\">' +
	'        <TocEntry Title=\"Tutorials\" Link=\"/Content/Tutorials/Tutorials.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Untitled\" DescendantCount=\"1\">' +
	'        <TocEntry Title=\"Welcome\" Link=\"/Content/Welcome.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Using the Wizard Builder\" DescendantCount=\"9\">' +
	'        <TocEntry Title=\"Using the Wizard Builder\" Link=\"/Content/Wizard_Builder/Using_the_Wizard_Builder.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Wizard Builder Toolbar\" Link=\"/Content/Wizard_Builder/Wizard_Builder_Toolbar.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Create a Wizard\" Link=\"/Content/Wizard_Builder/Create_a_Wizard.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Open a Wizard\" Link=\"/Content/Wizard_Builder/Open_a_Wizard.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Run a Wizard\" Link=\"/Content/Wizard_Builder/Run_a_Wizard.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Save a Wizard\" Link=\"/Content/Wizard_Builder/Save_a_Wizard.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Wizard Execution Mode\" Link=\"/Content/Wizard_Builder/Wizard_Execution_Mode.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Wizard Menu Location\" Link=\"/Content/Wizard_Builder/Wizard_Menu_Location.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Update Wizard List\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Wizard Items\" Link=\"/Content/Wizard_Builder/Items/Wizard_Items.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Working with COMET Windows\" DescendantCount=\"5\">' +
	'        <TocEntry Title=\"Moving and Hiding a Dock Window\" Link=\"/Content/Tools/Histogram_Window/Moving_and_Hiding_a_Dock_Window.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Display Gridlines on a Plot\" Link=\"/Content/Tools/Histogram_Window/Display_Gridlines_on_a_Plot.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Layer Information Window\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Message Log Window\" Link=\"/Content/Tools/Message_Log_Window/Message_Log_Window.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Scripting Window\" Link=\"/Content/Tools/Scripting_Window.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Background Plug-In Window\" Link=\"/Content/Tools/Background_PlugIn_Window.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Working with Images\" DescendantCount=\"10\">' +
	'        <TocEntry Title=\"Open a File\" Link=\"/Content/Importers_Exporters/Import_Data.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Pan\" Link=\"/Content/View/Pan.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Pan Mode\" Link=\"/Content/View/Pan_Mode.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Rotate\" Link=\"/Content/View/Rotate.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Zoom\" Link=\"/Content/View/Zoom.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Overview Window\" Link=\"/Content/Tools/Overview_Window.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Link/Unlink\" Link=\"/Content/Tools/Link_Unlink.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Image Chipping Window\" Link=\"/Content/Tools/Image_Chipping_Window.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Print the Active Window\" Link=\"/Content/Print_the_Active_Window.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Close a Window\" Link=\"/Content/Close_a_Window.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Working with Layers\" DescendantCount=\"3\">' +
	'        <TocEntry Title=\"Layer Information Window\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Modifying Layer Information\" Link=\"/Content/Layers/Working_with_Layers.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Layer Toolbar\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"AOI\" Link=\"/Content/AOI/AOI.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Annotation Layer\" Link=\"/Content/Annotation/Annotation_Layer.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Working with the COMET Main Application Window\" DescendantCount=\"3\">' +
	'        <TocEntry Title=\"Working with the COMET Main Application Window\" Link=\"/Content/Working_with_the_Main_Application_Window.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Hot Keys\" Link=\"/Content/Options/Keyboard_Shortcuts.htm\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Mouse Actions\" Link=\"/Content/Mouse_Actions.htm\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'</CatapultToc>'
);
