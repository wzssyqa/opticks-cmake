CMCXmlParser._FilePathToXmlStringMap.Add(
	'Skin',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultSkin Version=\"1\" Title=\"Opticks Help\" Top=\"0px\" Left=\"0px\" Width=\"1px\" Height=\"1px\" Tabs=\"TOC,Index,Search,Glossary\">' +
	'    <Toc LinesBetweenItems=\"True\" LinesFromRoot=\"False\" SingleClick=\"False\" PlusMinusSquares=\"False\" AlwaysShowSelection=\"False\" UseFolderIcons=\"False\" ImageListWidth=\"16\" BinaryStorage=\"False\" />' +
	'    <Stylesheet Link=\"Stylesheet.xml\">' +
	'    </Stylesheet>' +
	'</CatapultSkin>'
);
