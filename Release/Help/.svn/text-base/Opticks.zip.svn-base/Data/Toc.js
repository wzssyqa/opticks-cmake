CMCXmlParser._FilePathToXmlStringMap.Add(
	'Toc',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?><CatapultToc Version=\"1\" DescendantCount=\"226\"><TocEntry Title=\"Opticks\" Link=\"/Content/Welcome.htm\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"true\" DescendantCount=\"225\"><TocEntry Title=\"Welcome\" Link=\"/Content/Welcome.htm\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"true\" DescendantCount=\"0\" /><TocEntry Title=\"Opticks Studio\" Link=\"/Content/Working_with_the_Main_Application_Window.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"223\" Chunk=\"Toc_Chunk1.xml\"></TocEntry></TocEntry></CatapultToc>'
);
