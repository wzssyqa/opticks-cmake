CMCXmlParser._FilePathToXmlStringMap.Add(
	'Alias',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultAliasFile Version=\"1\" DefaultSkinName=\"OpticksSkin\" />'
);
